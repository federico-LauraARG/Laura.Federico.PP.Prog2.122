
package recup1122q2;

import java.util.Objects;


public abstract class Actividad {
    
    private String codigo;
    private String titulo;
    private FranjaHoraria franjaHoraria;
    private int duracionBase;

    public Actividad(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.franjaHoraria = franjaHoraria;
        this.duracionBase = duracionBase;
        validaciones();
    }

    

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public FranjaHoraria getFranjaHoraria() {
        return franjaHoraria;
    }

    public int getDuracionBase() {
        return duracionBase;
    }

    public abstract int getDuracionTotal();
    
    @Override
    public int hashCode() {
        return Objects.hash(this.codigo,this.titulo);
    }

    
    public void validaciones(){
        if(codigo == null || codigo.isBlank()){
            throw new IllegalArgumentException("El codigo no puede ser nulo ni estar en blanco.");
        }
        if(titulo == null || titulo.isBlank()){
            throw new IllegalArgumentException("El titulo es obligatorio y no puede estar en blanco.");
        }
        if(franjaHoraria == null){
            throw new IllegalArgumentException("La franja horaria es obligatoria.");
        }
    }
    
    
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if(obj instanceof Actividad otro){
            return(codigo.equals(otro.codigo) && titulo.equals(otro.titulo));
        }
        return false;
    }

    @Override
    public String toString() {
        return "Actividad{" + "codigo=" + codigo + ", titulo=" + titulo + ", franjaHoraria=" + franjaHoraria + ", duracionBase=" + duracionBase + '}';
    }

   

    
    
    
    
}
