
package recup1122q2;


public enum FranjaHoraria {
    MATUTINA,
    VESPERTINA,
    NOCTURNA;
}
