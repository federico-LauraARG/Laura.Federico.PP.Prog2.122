
package recup1122q2;


public interface Presentacion {
    
    public void presentacionDeLugar();
}
