
package recup1122q2;


public class ActividadDuplicadaException extends Exception{

    public ActividadDuplicadaException(String message) {
        super(message);
    }

   
    
    
}
