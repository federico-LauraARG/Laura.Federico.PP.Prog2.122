
package recup1122q2;


public class MuestraInteractiva extends Actividad implements Presentacion{
    
    private int cantidadEstaciones;

    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase,int cantidadEstaciones) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        this.cantidadEstaciones = cantidadEstaciones;
    }

    

    @Override
    public int getDuracionTotal(){
        return getDuracionBase() + 5 * this.cantidadEstaciones;
    }
    
    
    @Override
   public void presentacionDeLugar(){
        System.out.println("Realizando la presentacion de la charla...");
   }
   
}
   

