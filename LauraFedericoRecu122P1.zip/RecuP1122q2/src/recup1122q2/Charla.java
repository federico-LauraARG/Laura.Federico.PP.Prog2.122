
package recup1122q2;


public class Charla extends Actividad implements Reservas,Presentacion{
    
    private int minutos;
    private int cuposDisponibles;

    public Charla(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase,int minutos,int cuposDisponibles) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        this.minutos = minutos;
        this.cuposDisponibles = cuposDisponibles;
    }

    

   
    @Override
    public int getDuracionTotal(){
        return getDuracionBase() + this.minutos;
    }
    
    @Override
   public String reservaDeLugar(){
       if(cuposDisponibles <= 0){
           throw new IllegalStateException("No le quedan lugares disponibles.");
       }
       cuposDisponibles --;
       return " Reserva confirmada. Cupos restantes: " + cuposDisponibles;
   }
   
   @Override
   public void presentacionDeLugar(){
       System.out.println("Realizando la presentacion de la charla...");
   }
    
}
