package recup1122q2;

public class Taller extends Actividad implements Reservas {

    private int minutosAdicionales;
    private int cuposDisponibles;

    public Taller(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase, int minutosAdicionales,int cuposDisponibles) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        this.minutosAdicionales = minutosAdicionales;
    }

    @Override
    public int getDuracionTotal() {
        return getDuracionBase() + this.minutosAdicionales;
    }

    @Override
    public String reservaDeLugar() {
        if (cuposDisponibles <= 0) {
            throw new IllegalStateException("No le quedan lugares disponibles.");
        }
        cuposDisponibles--;
        return " Reserva confirmada. Cupos restantes: " + cuposDisponibles;
    }

}
