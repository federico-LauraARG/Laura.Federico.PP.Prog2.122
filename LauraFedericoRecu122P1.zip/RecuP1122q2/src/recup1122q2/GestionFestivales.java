
package recup1122q2;
import java.util.ArrayList;
import java.util.List;

public class GestionFestivales {
    private String nombre;
    private List<Actividad> actividades;

    public GestionFestivales(String nombre) {
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    public void agregarActividad(Actividad a) throws ActividadDuplicadaException{
        if(a == null){
            throw new IllegalArgumentException("La actividad a agregar no puede ser nula");
        }
        if(actividades.contains(a)){
            throw new ActividadDuplicadaException("Ya existe una actvidad resgistrada con el codigo: " + a.getCodigo() + " y titulo: " + a.getTitulo());
        }
        actividades.add(a);
    }
    
    
    public List<Actividad> obtenerActividades(){
        return this.actividades;
    }
    
    public List<Actividad> filtrarPorFranja(FranjaHoraria franja){
        List<Actividad> filtrados = new ArrayList<>();
        for(Actividad a : this.actividades){
            if(a.getFranjaHoraria() == franja){
                filtrados.add(a);
            }
        }
        return filtrados;
    }
    
     public List<Actividad> obtenerActividadesDeDuracionMaxima(int duracion){
        List<Actividad> filtrados = new ArrayList<>();
        for(Actividad a : this.actividades){
            if(a.getDuracionTotal() <= duracion){
                filtrados.add(a);
            }
        }
        return filtrados;
    }
    
    
    
}
