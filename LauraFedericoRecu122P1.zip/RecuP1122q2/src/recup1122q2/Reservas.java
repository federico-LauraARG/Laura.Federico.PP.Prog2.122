
package recup1122q2;


public interface Reservas {
    
    public String reservaDeLugar();
}
